import React from 'react';
import Rating from '@material-ui/lab/Rating';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import { TextField } from '@material-ui/core';

export default function App() {
const [ratingValue, setRatingValue, setRatingValue1] = React.useState(0);
return (
    <div style={{ display: 'block', padding: 30 }}>
    <h4>Ratings for Dinner</h4>
    <Box component="fieldset" mb={3} borderColor="transparent">
        <Typography component="legend">
            Please rate this dish:
        </Typography>
    <h1> <img 
      src="https://www.averiecooks.com/wp-content/uploads/2021/01/garlicbutterchicken-5.jpg"
      alt="new"
      width = "200"
      height = "300"
      /></h1>
        <Rating
        name="Dish1"
        value={ratingValue}
        onChange={(event, newValue) => {
            setRatingValue(newValue);
        // calls the backend function with newValue as the parameter
        // newValue is an integer and the backend function will push this value to a database
        }}
        />
  <p><TextField id="outlined-basic" label= "Comments" variant="outlined" /></p>
 
    </Box>

  <Box component="fieldset" mb={3} borderColor="transparent">
        <Typography component="legend">
            Please rate this dish:
        </Typography>
    <h1> <img 
      src="https://www.chewoutloud.com/wp-content/uploads/2017/06/easy-lemon-butter-fish-0.jpg"
      alt="new"
      width = "200"
      height = "300"
      /></h1>
        <Rating
        name="Dish2"
        value1={ratingValue}
        onChange={(event, newValue) => {
            setRatingValue1(newValue);
            // calls the backend function with newValue as the parameter
        // newValue is an integer and the backend function will push this value to a database
        }}
        />
  <p><TextField id="outlined-basic" label="Comments" variant="outlined" /></p>
    </Box>
    </div> 
);
}
